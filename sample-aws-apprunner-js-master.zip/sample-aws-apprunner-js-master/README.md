# AWS App Runner Nodejs Example app

In this sample applciaiton , we have single root endpoint which is going to return hello world message with environment variable. 

## Step by step guide to run the application

First you need to install all the libraries.

```npm install```

Start the server

```node app.js```

Server will start running on default 8080 port and you can access it

```http://localhost:8080```

